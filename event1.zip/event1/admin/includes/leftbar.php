	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				
			
<li><a href="#"><i class="fa fa-files-o"></i>Place</a>
<ul>
<li><a href="create-brand.php">Add place</a></li>
<li><a href="manage-brands.php">Manage place</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-sitemap"></i>Event</a>
					<ul>
						<li><a href="post-avehical.php">Post Event</a></li>
						<li><a href="manage-vehicles.php">Manage Event</a></li>
					</ul>
				</li>
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Manage Booking</a></li>

		
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage Query</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Reg Users</a></li>
			
			
			</ul>
		</nav>